//Constante require mysql
const mysql = require('mysql')

//Constante de conexão com banco de dados
const conexao = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'admin',
    database: 'agenda-petshop'
})
//O module. exports variável retornada a partir da função require()
module.exports = conexao